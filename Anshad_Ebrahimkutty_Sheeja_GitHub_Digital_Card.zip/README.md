
# Digital Business Card

This is the personal digital business card for **Anshad Ebrahimkutty Sheeja**, Managing Director at Farecraft.

## Contents

- `index.html`: The digital card webpage
- `profile_picture_resized.jpg`: Profile image
- `Anshad_Ebrahimkutty_Sheeja_QR.png`: QR code linking to vCard
- `Anshad_Ebrahimkutty_Sheeja_Digital_Marketing.vcf`: Downloadable contact file

## Hosted Example

Once uploaded, the card will be available at:

`https://Anshad786.github.io/digital-card/`
